// ESP8266ctrl.h v.ALFA
// Created 22/09/2024

// WiFi NAME AND PASSWORD
////const String ssid = "MOVISTAR_1324";
////const String pswd = "8GZWaiEQet87DnuGb8To";

bool sendATCommand(String command) {
  String response = "";
  unsigned long startTime = millis();
  while (millis() - startTime < 5000) { // Timeout set to 5 seconds
    if (myESP.available()) {
      char c = myESP.read();
      response += c;
#ifdef DEBUG 		 
      Debug.print(c);
#endif		 

      if (response.indexOf("OK") != -1) {
        myNex.writeStr("Monitor.txt+", command + " -> OK\\r");
        return true;
      } else if (response.indexOf("FAIL") != -1) {
        myNex.writeStr("Monitor.txt+", command + " -> FAIL\\r");
        return false;
      }
    }
  }
  myNex.writeStr("Monitor.txt+", command + " -> TIMEOUT\\r");
  return false;
}

void sendCommandAndDisplayResponse(String command, const char* displayText) {
#ifdef DEBUG 	
  Debug.println("Sending: " + command);
#endif	
  myESP.println(command);
  sendATCommand(displayText);
}

String readResponse() {
  String response = "";
  unsigned long startTime = millis();
  while (millis() - startTime < 5000) { // Timeout set to 5 seconds
    if (myESP.available()) {
      char c = myESP.read();
      response += c;
    }
  }
  return response;
}

void WiFi_CONN(){
	myNex.writeStr("Monitor.txt", "CONNECTION TO WiFi...\\r");
   delay(500);
	sendCommandAndDisplayResponse("ATE0", "ATE0");
	sendCommandAndDisplayResponse("AT", "AT");
	sendCommandAndDisplayResponse("AT+CWMODE=1", "AT+CWMODE=1");
	sendCommandAndDisplayResponse("AT+CWQAP", "AT+CWQAP");
   // Connect to WiFi network (AT+CWJAP command)
	sendCommandAndDisplayResponse("AT+CWJAP=\"" + String(Settings2R.SSID) + "\",\"" + String(Settings2R.PSWD) + "\"", "AT+CWJAP");
   // Check IP address (AT+CIFSR command)
   sendCommandAndDisplayResponse("AT+CIFSR", "AT+CIFSR");
	myNex.writeStr("Monitor.txt+", "CONNECTED TO WiFi!!!\\r");
	delay(10000);
}

void NTP_Server_Access() { //NTP_Server_Access()
	myNex.writeStr("Monitor.txt", "ACCESING TO NTP SERVER...\\r");
	
  unsigned long startTime = millis();
  bool success = false;

  while (millis() - startTime < 6000) { // Timeout set to 5 seconds
 	myESP.println("AT+CIPSNTPCFG=1,1,\"" + String(Settings2R.SRVR1) + "\",\"" + String(Settings2R.SRVR2) + "\",\"" + String(Settings2R.SRVR3) + "\"");
	myNex.writeStr("Monitor.txt+", "AT+CIPSNTPCFG=1,1," + String(Settings2R.SRVR1)+"\\r");
	myNex.writeStr("Monitor.txt+", "                  " + String(Settings2R.SRVR2)+"\\r");
	myNex.writeStr("Monitor.txt+", "                  " + String(Settings2R.SRVR3) + " -> ");
	delay(2000); // Adjust this delay based on the response time expected

   String response = readResponse();
#ifdef DEBUG 	  
   Debug.println("Response: " + response);
#endif	
   if (response.indexOf("OK") != -1) {
		myNex.writeStr("Monitor.txt+", "OK\\r");
	   success = true;
		myNex.writeStr("Monitor.txt+", "NTP SERVER ACCESSED!!!" ); 
      break;
    }
  }

  if (!success) {
     myNex.writeStr("Monitor.txt+", "AT+CIPSNTPCFG=1,2,es.pool.ntp.org -> FAIL\\r");
     // Handle if the routine fails after the timeout
     // You can add further logic or take corrective actions if required
   }
	delay(3000);
}

void TAKING_DateTime() {
	 unsigned long startTime = millis();
    bool success = false;
    bool receivedFirstResponse = false; // Flag to track the first response
	 myNex.writeStr("Monitor.txt", "TAKEN DATE & TIME...\\r"); // Send the command to Nextion once
	 delay(500);
    myNex.writeStr("Monitor.txt+", "AT+CIPSNTPTIME? -> "); // Send the command to Nextion once

    while (millis() - startTime < 10000) { // Timeout set to 10 seconds
        myESP.println("AT+CIPSNTPTIME?");
        delay(1000); // Adjust this delay based on the expected response time

        String response = readResponse();

        if (!receivedFirstResponse && response.indexOf("+CIPSNTPTIME:") != -1) {
            DateTime = response.substring(response.indexOf(":") + 1); // Assign value to DateTime
			   DateTime = DateTime.substring(0, 24); // Modify the DateTime format for Nextion
            myNex.writeStr("Monitor.txt+", DateTime + " -> ");
            receivedFirstResponse = true;

        } else if (receivedFirstResponse && response.indexOf("OK") != -1) {
            if (DateTime.length() > 0) {
                myNex.writeStr("Monitor.txt+", "OK\\r");
					 myNex.writeStr("Monitor.txt+", "- NOTE: If we are in Daylight Saving Time,\\r");
					 myNex.writeStr("Monitor.txt+", "        the time will be finally corrected.\\r");
                myNex.writeStr("Monitor.txt+", "DATE AND TIME TAKEN!!!\\r");
                success = true;
				    break;
            }
        }
    }

    if (!success) {
        myNex.writeStr("Monitor.txt+", " -> FAIL\\r");
        myNex.writeStr("Monitor.txt+", "DATE AND TIME NOT TAKEN!!!\\r");
        myNex.writeStr("Monitor.txt+", "SWITCH OFF AND ON AGAIN!!!\\r");
        // Stop the execution of the program here if needed
        while (true) {
            // Stuck here, you might add additional handling or exit strategy
        }
    }
			delay(3000);
}


// Define a function to check if the current date is in Daylight Saving Time (DST) period for Spain
bool is_dst(int year, int month, int day) {
    // DST starts on the last Sunday in March
    int dst_start_day = 31 - (5*year/4 + 4) % 7;
    // DST ends on the last Sunday in October
    int dst_end_day = 31 - (5*year/4 + 1) % 7;

    // If the current date is between the start and end of DST, return true
    if ((month > 3 && month < 10) || (month == 3 && day >= dst_start_day) || (month == 10 && day <= dst_end_day)) {
        return true;
    } else {
        return false;
    }
}

void SEND_DateTime_TO_NEXTION(String DateTime, bool isOK) {
	myNex.writeStr("Monitor.txt", "SEND DATE & TIME TO DISPLAY...\\r");
	delay(500);
    // Extract and process individual date and time components
    String dayOfWeek = DateTime.substring(0, 3);
    String month = DateTime.substring(4, 7);
    String day = DateTime.substring(8, 10);
    String hour = DateTime.substring(11, 13);
    String minute = DateTime.substring(14, 16);
    String second = DateTime.substring(17, 19);
    String year = DateTime.substring(20, 24);

    // Trim extracted components
    dayOfWeek.trim();
    month.trim();
    day.trim();
    hour.trim();
    minute.trim();
    second.trim();
    year.trim();
	
	 int dayOfWeekNum = -1; // convertDayOfWeekToNumber(dayOfWeek);
    int monthNum = -1; // convertMonthToNumber(month);

    // Send processed data to Nextion display
    myNex.writeStr("Monitor.txt", "SENDING Date & Time TO DISPLAY...\\r");
    myNex.writeStr("Monitor.txt+", DateTime);
    delay(1000);
	 
    myNex.writeNum("rtc0", year.toInt());
    // Convert month string to a number (January=1, February=2, ..., December=12)
    if (month.equals("Jan")) {
        monthNum = 1;
    } else if (month.equals("Feb")) {
        monthNum = 2;
    } else if (month.equals("Mar")) {
        monthNum = 3;
    } else if (month.equals("Apr")) {
        monthNum = 4;
    } else if (month.equals("May")) {
        monthNum = 5;
    } else if (month.equals("Jun")) {
        monthNum = 6;
    } else if (month.equals("Jul")) {
        monthNum = 7;
    } else if (month.equals("Aug")) {
        monthNum = 8;
    } else if (month.equals("Sep")) {
        monthNum = 9;
    } else if (month.equals("Oct")) {
        monthNum = 10;
    } else if (month.equals("Nov")) {
        monthNum = 11;
    } else if (month.equals("Dec")) {
        monthNum = 12;
    } else {
#ifdef DEBUG 		 
        Debug.println("Invalid month");
#endif		 
    }
    myNex.writeNum("rtc1", monthNum);
    delay(100);
    myNex.writeNum("rtc2", day.toInt());
    delay(100);
	 
    // If the current date is in DST, increment the hour
    if (is_dst(year.toInt(), monthNum, day.toInt())) {
        hour = String(hour.toInt() + 1);
    }	 
	 
// Add 30 seconds to compensate for communication delay
int newSecond = (second.toInt() + 30) % 60;
int newMinute = minute.toInt() + (second.toInt() + 30) / 60;
int newHour = hour.toInt() + newMinute / 60;
newMinute %= 60;
newHour%= 24;

	// Send current time to Nextion
myNex.writeNum("rtc3", newHour);
delay(100);
myNex.writeNum("rtc4", newMinute);
delay(100);
myNex.writeNum("rtc5", newSecond);
	 

if (dayOfWeek.equals("Sun")) {
        dayOfWeekNum = 0;
    } else if (dayOfWeek.equals("Mon")) {
        dayOfWeekNum = 1;
    } else if (dayOfWeek.equals("Tue")) {
        dayOfWeekNum = 2;
    } else if (dayOfWeek.equals("Wed")) {
        dayOfWeekNum = 3;
    } else if (dayOfWeek.equals("Thu")) {
        dayOfWeekNum = 4;
    } else if (dayOfWeek.equals("Fri")) {
        dayOfWeekNum = 5;
    } else if (dayOfWeek.equals("Sat")) {
        dayOfWeekNum = 6;
    } else {
#ifdef DEBUG		 
        Debug.println("Invalid day of the week");
#endif		 
    }
    myNex.writeNum("rtc6", dayOfWeekNum);

    if (isOK) {
        // delay(1000); // Adjust delay as necessary before sending "OK" response
        myNex.writeStr("Monitor.txt+", " -> OK");
        myNex.writeStr("Monitor.txt+", "Date & Time SENT TO DISPLAY!!!\\r");
    }
}
