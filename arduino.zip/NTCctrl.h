// NTCctrl.h v.ALFA
// Created 22/09/2024

// steinhart-hart Beta coefficients for thermistor TEKMAR Typ 3111, 3115 and similar (2K)
// Coeficients are calculated from https://www.thinksrs.com/downloads/programs/Therm%20Calc/NTCCalibrator/NTCcalculator.htm
// Conversion from e notation to decimal from https://calculadorasonline.com/calculadora-notacion-cientifica-convertidor-operaciones/
// NTC0 (OUTDOOR) from -5 0 20
//  -5  7066 A0 = 1.243603926e-3
//   0  5632 B0 = 2.697974414e-4
// +20  2431 C0 = 1.356227226e-7
// Beta = 3322.84
// NTC1 (SUPPLY) from 20 40 60
// +40  1150  B1 = 1.359883972e-3
// +50  2431 A1 = 2.456998814e-3
// +60  587  C1 = 2.911149166e-7
// Beta =3484.42
// NTC2 (BOILER) from 25 45 65
// +25  2000 A2 = 1.325464129e-3
// +45   966 B2 = 2.536171132e-4
// +65   501 C2 = 2.296195108e-7
// Beta = 3451.53
// NTC3 (RETURN) from 20 30 40
// +20  2431 A3 = 1.303295436e-3
// +30  1655 B3 = 2.583748952e-4
// +40  1150 C3 = 1.975840690e-7
// Beta = 3417.01


float NTC0_NOM = 2000, NTC0_TEMP_NOM = 25, NTC0_SERIES_RES = 2000, Bcoeff0 = 3322.84;
float NTC1_NOM = 2000, NTC1_TEMP_NOM = 25, NTC1_SERIES_RES = 2000, Bcoeff1 = 3484.42;
float NTC2_NOM = 2000, NTC2_TEMP_NOM = 25, NTC2_SERIES_RES = 2000, Bcoeff2 = 3451.53;
float NTC3_NOM = 2000, NTC3_TEMP_NOM = 25, NTC3_SERIES_RES = 2000, Bcoeff3 = 3417.01;

float steinhart, average;
float tempInt;

#define NUMSAMPLES 10
int samples[NUMSAMPLES];

void sample_NTC0() {
  // take N samples in a row, with a slight delay
  for (i=0; i< NUMSAMPLES; i++) {
   samples[i] = analogRead(NTC0pin);
   delay(100);
  }
  // average all the samples out
  steinhart = 0;
  average = 0;
  for (i=0; i< NUMSAMPLES; i++) {
     average += samples[i];
  }
  average /= NUMSAMPLES;

  // convert the value to resistance
  average = 1023 / average - 1;
  average = NTC0_SERIES_RES/average; //SERIESRESISTOR / average;

  steinhart = average / NTC0_NOM; //THERMISTORNOMINAL;     // (R/Ro)
  steinhart = log(steinhart);                  // ln(R/Ro)
  steinhart /= 3950; //3322.84; //BCOEFFICIENT;                   // 1/B * ln(R/Ro)
  steinhart += 1.0 / (NTC0_TEMP_NOM + 273.15); //TEMPERATURENOMINAL + 273.15); // + (1/To)
  steinhart = 1.0 / steinhart;                 // Invert
  steinhart -= 273.15;                         // convert to C
  OUTDOORtemp = steinhart;
  #ifdef DEBUG
  Debug.print("OUTDOORtemp: "); Debug.println(OUTDOORtemp);
  #endif
}

void sample_NTC1() {
  // take N samples in a row, with a slight delay
  for (i=0; i< NUMSAMPLES; i++) {
   samples[i] = analogRead(NTC1pin);
   delay(100);
  }
  // average all the samples out
  steinhart = 0;
  average = 0;
  for (i=0; i< NUMSAMPLES; i++) {
     average += samples[i];
  }
  average /= NUMSAMPLES;

  // convert the value to resistance
  average = 1023 / average - 1;
  average = NTC1_SERIES_RES/average; //SERIESRESISTOR / average;

  steinhart = average / NTC1_NOM; //THERMISTORNOMINAL;     // (R/Ro)
  steinhart = log(steinhart);                  // ln(R/Ro)
  steinhart /= 3950; //3322.84; //BCOEFFICIENT;                   // 1/B * ln(R/Ro)
  steinhart += 1.0 / (NTC1_TEMP_NOM + 273.15); //TEMPERATURENOMINAL + 273.15); // + (1/To)
  steinhart = 1.0 / steinhart;                 // Invert
  steinhart -= 273.15;                         // convert to C
  SUPPLYtemp = steinhart;
  #ifdef DEBUG
	//Debug.print("Steinhart  : "); Debug.println(steinhart);
	Debug.print("SUPPLY temp: "); Debug.println(SUPPLYtemp);
   #endif
}

void sample_NTC2() {
  // take N samples in a row, with a slight delay
  for (i=0; i< NUMSAMPLES; i++) {
   samples[i] = analogRead(NTC2pin);
   delay(100);
  }
  // average all the samples out
  steinhart = 0;
  average = 0;
  for (i=0; i< NUMSAMPLES; i++) {
     average += samples[i];
  }
  average /= NUMSAMPLES;

  // convert the value to resistance
  average = 1023 / average - 1;
  average = NTC2_SERIES_RES/average; //SERIESRESISTOR / average;

  steinhart = average / NTC2_NOM; //THERMISTORNOMINAL;     // (R/Ro)
  steinhart = log(steinhart);                  // ln(R/Ro)
  steinhart /= 3950; //3322.84; //BCOEFFICIENT;                   // 1/B * ln(R/Ro)
  steinhart += 1.0 / (NTC2_TEMP_NOM + 273.15); //TEMPERATURENOMINAL + 273.15); // + (1/To)
  steinhart = 1.0 / steinhart;                 // Invert
  steinhart -= 273.15;                         // convert to C
  BOILERtemp = steinhart;
/*
Debug.print("Steinhart  : "); Debug.println(steinhart);
Debug.print("BOILER temp: "); Debug.println(BOILERtemp);
*/
}

void sample_NTC3() {
  // take N samples in a row, with a slight delay
  for (i=0; i< NUMSAMPLES; i++) {
   samples[i] = analogRead(NTC3pin);
   delay(100);
  }
  // average all the samples out
  steinhart = 0;
  average = 0;
  for (i=0; i< NUMSAMPLES; i++) {
     average += samples[i];
  }
  average /= NUMSAMPLES;

  // convert the value to resistance
  average = 1023 / average - 1;
  average = NTC3_SERIES_RES/average; //SERIESRESISTOR / average;

  steinhart = average / NTC3_NOM; //THERMISTORNOMINAL;     // (R/Ro)
  steinhart = log(steinhart);                  // ln(R/Ro)
  steinhart /= 3950; //3322.84; //BCOEFFICIENT;                   // 1/B * ln(R/Ro)
  steinhart += 1.0 / (NTC3_TEMP_NOM + 273.15); //TEMPERATURENOMINAL + 273.15); // + (1/To)
  steinhart = 1.0 / steinhart;                 // Invert
  steinhart -= 273.15;                         // convert to C
  RETURNtemp = steinhart;
/*
Debug.print("Steinhart  : "); Debug.println(steinhart);
Debug.print("RETURN temp: "); Debug.println(RETURNtemp);
*/
}


void NTCs_INIT() {
	myNex.writeStr("Monitor.txt", "START NTCs INITIALIZATION...\\r");
	delay(500);
  myNex.writeStr("Monitor.txt+", "- NTC0 (Outdoor): ");
  if (Settings1R.NTC0_Instl) {
    NTC0pin = 0;
    pinMode(NTC0pin, INPUT);
    myNex.writeStr("Monitor.txt+", "Installed");
  } else {
    myNex.writeStr("Monitor.txt+", "NOT installed");
  }
  myNex.writeStr("Monitor.txt+", "\\r");
  myNex.writeStr("Monitor.txt+", "- NTC1 (Supply) : ");
  if (Settings1R.NTC1_Instl) {
    NTC1pin = 1;
    pinMode(NTC1pin, INPUT);
    myNex.writeStr("Monitor.txt+", "Installed");
  } else {
    myNex.writeStr("Monitor.txt+", "NOT installed");
  }
  myNex.writeStr("Monitor.txt+", "\\r");
  myNex.writeStr("Monitor.txt+", "- NTC2 (Boiler) : ");
  if (Settings1R.NTC2_Instl) {
    NTC2pin = 2;
    pinMode(NTC2pin, INPUT);
    myNex.writeStr("Monitor.txt+", "Installed");
  } else {
    myNex.writeStr("Monitor.txt+", "NOT installed");
  }
  myNex.writeStr("Monitor.txt+", "\\r");
  myNex.writeStr("Monitor.txt+", "- NTC3 (Return) : ");
  if (Settings1R.NTC3_Instl) {
    NTC3pin = 3;
    pinMode(NTC3pin, INPUT);
    myNex.writeStr("Monitor.txt+", "Installed");
  } else {
    myNex.writeStr("Monitor.txt+", "NOT installed");
  }
  myNex.writeStr("Monitor.txt+", "\\rEND NTCs INITIALIZATION 01 !!!");
  delay(3000);
}


// CALCULATION OF THE SUPPLYING TEMPERATURE
void Get_CalcSUPPLYtemp() {
  CalcSUPPLYtemp = Settings1R.SetPoint + Reset_Ratio * (Settings1R.SetPoint - OUTDOORtemp);
  #ifdef DEBUG
  Debug.print("CalcSUPPLYtemp: ");Debug.println(CalcSUPPLYtemp);
  #endif
}

void FIRST_READ_TEMPs(){
  myNex.writeStr("Monitor.txt", "FIRST READING NTCs TEMPERATURES...\\r");
  delay(500);
  // Get NTC temperatures
  if (Settings1R.NTC0_Instl) {
    sample_NTC0();
    myNex.writeStr("Monitor.txt+", "- Outdoor temp.     : ");
    // Convert float to String
    String OUTDOORtempString = String(OUTDOORtemp);
    myNex.writeStr("Monitor.txt+", OUTDOORtempString);
    myNex.writeStr("Monitor.txt+", "ºC\\r");
  }
  if (Settings1R.NTC1_Instl) {
    sample_NTC1();
    myNex.writeStr("Monitor.txt+", "- Supply temp.      : ");
    // Convert float to String
    String SUPPLYtempString = String(SUPPLYtemp);
    myNex.writeStr("Monitor.txt+", SUPPLYtempString);
    myNex.writeStr("Monitor.txt+", "ºC\\r");
  }
  if (Settings1R.NTC2_Instl) {
    sample_NTC2();
    myNex.writeStr("Monitor.txt+", "- Boiler temp.      : ");
    // Convert float to String
    String BOILERtempString = String(BOILERtemp);
    myNex.writeStr("Monitor.txt+", BOILERtempString);
    myNex.writeStr("Monitor.txt+", "ºC\\r");
  }
  if (Settings1R.NTC3_Instl) {
    sample_NTC3();
    myNex.writeStr("Monitor.txt+", "- Return temp.      : ");
    // Convert float to String
    String RETURNtempString = String(RETURNtemp);
    myNex.writeStr("Monitor.txt+", RETURNtempString);
    myNex.writeStr("Monitor.txt+", "ºC\\r");
  }
  Get_CalcSUPPLYtemp();
  String CalcSUPPLYtempString = String(CalcSUPPLYtemp);
  myNex.writeStr("Monitor.txt+", "- Calc. SUPPLY temp.: ");
  myNex.writeStr("Monitor.txt+", CalcSUPPLYtempString);
  myNex.writeStr("Monitor.txt+", "ºC\\r");
  myNex.writeStr("Monitor.txt+", "- NOTE: Usually first readings are not valid.\\r");
  myNex.writeStr("Monitor.txt+", "END FIRST READING NTCs TEMPERATURES!!!\\r");
  delay(3000);
}

void Get_NTCsTemps() {
  if (Settings1R.NTC0_Instl) {
    sample_NTC0();
  }
  if (Settings1R.NTC1_Instl) {
    sample_NTC1();
  }
  if (Settings1R.NTC2_Instl) {
    sample_NTC2();
  }
  if (Settings1R.NTC3_Instl) {
    sample_NTC3();
  }
	Get_CalcSUPPLYtemp();
	UPDATE_TEMPS();
}
