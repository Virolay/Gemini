// tekmar.h v.ALFA
// Created 22/09/2024

int i = 0; // Multiple uses
unsigned int DSTstate = 0; // Last minute modification in anticipation of Daylight Saving Time being canceled
bool continueRunning = true; // Global flag
String DateTime; // Global to be used in Date & Time functions

void Delay(){ delay(1000); }

/*
// Pin Definitions
const int pinLimitSwitchOPEN = 28;
const int pinLimitSwitchCLOSE = 26;
const int pinRelayOPEN = 31;
const int pinRelayCLOSE = 30;
const int pinLEDOPEN = 23;
const int pinLEDCLOSE = 25;
const int pinLEDPAUSE = 27;
*/

// OUTPUT CONTROL PINS FOR VALVE
const int RelayOPENpin = 31;
const int RelayCLOSEpin = 30;
const int LED_OPENpin = 23;
const int LED_CLOSEpin = 25;
const int LED_PAUSEpin = 27;
// INPUT CONTROL PINS FOR VALVE
const int LSW_OPENpin = 20;
const int LSW_CLOSEpin = 21;

int NTC0pin , NTC1pin, NTC2pin, NTC3pin;

// VARIABLES FOR 'RESET RATIO' CALCULATIONS
float U = 0;
float k = 0;
float Reset_Ratio = 0;

// GENERAL VARIABLES
float OUTDOORtemp = 0.0;
float SUPPLYtemp = 0.0;
float BOILERtemp = 0.0;
float RETURNtemp = 0.0;
float CalcSUPPLYtemp = 0.0;

// Flag variables for interrupts
volatile bool interruptOpen = false;
volatile bool interruptClose = false;

// Variables for Scheduler
int Curr_hour = 0;
int Curr_minute = 0;
int Curr_interval = 0;
int Next_interval = 0;
int Start_hour = 0;
int Start_mins = 0;
int End_hour = 0;
int End_mins = 0;
bool flagTrip = false;

// Functions to control OPEN and CLOSE VALVE by limit switches
void handleOpenInterrupt() {
  interruptOpen = !digitalRead(LSW_OPENpin); // Invert the state for active-low switches
}

void handleCloseInterrupt() {
  interruptClose = !digitalRead(LSW_CLOSEpin); // Invert the state for active-low switches
}
/*
// PID variables
int eeADDRPIDctrl = 0x0020;
struct PIDctrl0 {
	float Kp;
	float Ki;
	float Kd;
};

PIDctrl0 PIDctrl0W = {0.55, 0.22, 0.11};
PIDctrl0 PIDctrl0R;
*/

// WiFi variables
int eeADDRsettings2 =0x0040;
struct Settings2 {
  char SRVR1[21];  // Always number of characters + 1 (null)
  char SRVR2[21];
  char SRVR3[21];
  char SSID[21];
  char PSWD[21];
  float OPENINGtime;
  float CLOSINGtime;
  float PAUSINGtime;
};

Settings2 Settings2W = {"time.google.com", "es.pool.ntp.org", "hora.roa.es", "MOVISTAR_1324", "8GZWaiEQet87DnuGb8To", 6.0, 6.0, 20.0};
Settings2 Settings2R;

// tekmar constant variables
int eeADDRsettings1 =0x0E0;
struct Settings1 {
  float BlrPWR;
  float maxSuppTemp;
  float minOutdTemp;
  float SetPoint;
  float SetBack;
  float Trip;
  bool NTC0_Instl;
  bool NTC1_Instl;
  bool NTC2_Instl;
  bool NTC3_Instl;
};

Settings1 Settings1W = { 2000.0, 60.0, -5.0, 21.0, 19.0, 18.0, true, true, true, true};
Settings1 Settings1R;

// Scheduler variables
int eeADDRschedr =0x0120;
struct Schedr {
  int S1H, S1M, E1H, E1M, S2H, S2M, E2H, E2M;
  int S3H, S3M, E3H, E3M, S4H, S4M, E4H, E4M;
  int S5H, S5M, E5H, E5M, S6H, S6M, E6H, E6M;

  //bool flagTrip;
};

Schedr SchedrW = { 6, 15, 7, 30, 13, 15, 14, 15, 16, 0, 21, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
Schedr SchedrR;
