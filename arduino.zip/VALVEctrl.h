// VALVEctrl.h v.ALFA
// Created 22/09/2024

bool valLSW_OPEN = false;
bool valLSW_CLOSE = false;

volatile int state = LOW;  // To make sure variables shared between an ISR
//the main program are updated correctly,declare them as volatile.

// VARIABLES FOR VALVE TIME CONTROL
float valveOPENINGtime = 3000;   // 3"
float ValveCLOSINGtime = 3000;   // 3"
float ValvePAUSINGtime = 10000;  // 10"
float ValveERROR = 0.00;

boolean valvePAUSE = true;
boolean valveCLOSE = false;
boolean valveOPEN = false;
/*
// VARIABLES FOR PID CALCULATIONS
float error, last_error, integral, derivative, output;

void PIDcalculations() {
  // CALCULATE ERROR
  error = CalcSUPPLYtemp - SUPPLYtemp;
  // CALCULATE INTEGRAL
  integral += error;
  // CALCULATE DERIVATIVE
  derivative = error - last_error;
  // CALCULATE OUTPUT
  output = PIDctrl0R.Kp * error + PIDctrl0R.Ki * integral + PIDctrl0R.Kd * derivative;
}
*/
void ValveStatus() {
  myNex.writeStr("page 0");  // Assuming this function is correct for setting the page

  if (valveOPEN == true && valveCLOSE == false && valvePAUSE == false) {
    myNex.writeStr("STATUS.txt", "OPENING");
#ifdef DEBUG 	  
    Debug.println("OPENING");
#endif	  
  } else if (valveOPEN == false && valveCLOSE == true && valvePAUSE == false) {
    myNex.writeStr("STATUS.txt", "CLOSING");
#ifdef DEBUG 	  
    Debug.println("CLOSING");
#endif	  
  } else if (valveOPEN == false && valveCLOSE == false && valvePAUSE == true) {
    myNex.writeStr("STATUS.txt", "PAUSING");
#ifdef DEBUG 	  
    Debug.println("PAUSING");
#endif	  
  } else {
    myNex.writeStr("STATUS.txt", "FAIL!!!");
#ifdef DEBUG 	  
    Debug.println("FAIL!!!");
#endif	  
  }
}

void OPEN_VALVE() {
  ValveStatus();
  // LEDs
  digitalWrite(LED_OPENpin, HIGH);
  digitalWrite(LED_PAUSEpin, LOW);
  digitalWrite(LED_CLOSEpin, LOW);
  // Relays
  digitalWrite(RelayOPENpin, HIGH);
  digitalWrite(RelayCLOSEpin, LOW);
}

void PAUSE_VALVE() {
  ValveStatus();
  // LEDs
  digitalWrite(LED_OPENpin, LOW);
  digitalWrite(LED_PAUSEpin, HIGH);
  digitalWrite(LED_CLOSEpin, LOW);
  // Relays
  digitalWrite(RelayOPENpin, LOW);
  digitalWrite(RelayCLOSEpin, LOW);
}

void CLOSE_VALVE() {
  ValveStatus();
  // LEDs
  digitalWrite(LED_OPENpin, LOW);
  digitalWrite(LED_PAUSEpin, LOW);
  digitalWrite(LED_CLOSEpin, HIGH);
  // Relays
  digitalWrite(RelayOPENpin, LOW);
  digitalWrite(RelayCLOSEpin, HIGH);
}

// LIMIT SWITCHES OPERATION
// ========================
// valve OPEN  = 0; limit SWITCH CAM OPEN-LSW  = CLOSE; OPEN-LSW  = 5
// valve CLOSE = 0; limit SWITCH CAM CLOSE-LSW = CLOSE; CLOSE-LSW = 5
// valve OPEN  = 1; limit SWITCH CAM OPEN-LSW  = CLOSE; OPEN-LSW  = 5
// valve CLOSE = 0; limit SWITCH CAM CLOSE-LSW = CLOSE; CLOSE-LSW = 5
// valve OPEN  = 1; limit SWITCH CAM OPEN-LSW  = OPEN ; OPEN-LSW  = 0
// valve CLOSE = 0; limit SWITCH CAM CLOSE-LSW = CLOSE; CLOSE-LSW = 5
// valve OPEN  = 0; limit SWITCH CAM OPEN-LSW  = CLOSE; OPEN-LSW  = 5
// valve CLOSE = 1; limit SWITCH CAM CLOSE-LSW = CLOSE; CLOSE-LSW = 5
// valve OPEN  = 0; limit SWITCH CAM OPEN-LSW  = CLOSE; OPEN-LSW  = 5
// valve CLOSE = 1; limit SWITCH CAM CLOSE-LSW = OPEN ; CLOSE-LSW = 0

// FUNCTION TO CONTROL A FOUR-WAY VALVE
// Function to control the four-way valve
void Four_way_valve_control() {
  ///Get_NTCsTemps();
  ///Get_CalcSUPPLYtemp();
#ifdef DEBUG
  Debug.print("SUPPLYtemp: ");
  Debug.println(SUPPLYtemp);
  Debug.print("CalcSUPPLYtemp: ");
  Debug.println(CalcSUPPLYtemp);
#endif
  // OPEN VALVE
  if (SUPPLYtemp <= CalcSUPPLYtemp - 2 && valvePAUSE == true && valveCLOSE == false && millis() > valveOPENINGtime) {
    ValveERROR = (CalcSUPPLYtemp - 2) - SUPPLYtemp;

#ifdef DEBUG
    Debug.print("ValveERROR : ");
    Debug.println(ValveERROR);
#endif
    if (ValveERROR <= 2) {  // If the difference is small
      valveOPENINGtime = millis() + 3000 - 1000 + (ValveERROR * 500);
#ifdef DEBUG
      Debug.println("If Supply <= CalcSupply - 2 then OPEN SMALL");
#endif
    } else {  // If the difference is big
      valveOPENINGtime = millis() + 3000;
#ifdef DEBUG
      Debug.println("If Supply <= CalcSupply then OPEN BIG");
#endif
    }

    valveCLOSE = false;
    valvePAUSE = false;
    valveOPEN = true;
    OPEN_VALVE();
  }

  // PAUSE VALVE
  if (valvePAUSE == false && millis() > ValvePAUSINGtime) {
    if (SUPPLYtemp > CalcSUPPLYtemp + 10) {  // If the difference is greater than 10 degrees, no pause
#ifdef DEBUG
      Debug.println("If Supply > CalcSupply + 10 then NO PAUSE");
#endif
      ValveCLOSINGtime = millis();
      valveOPENINGtime = millis();
    } else {
#ifdef DEBUG
      Debug.println("If Supply <= CalcSupply then PAUSE time = OPEN or CLOSE times");
#endif
      ValvePAUSINGtime = millis() + 3000;
      ValveCLOSINGtime = ValvePAUSINGtime;
      valveOPENINGtime = ValvePAUSINGtime;
    }
    valveOPEN = false;
    valveCLOSE = false;
    valvePAUSE = true;
    PAUSE_VALVE();
  }

  // CLOSE VALVE
  if (SUPPLYtemp >= CalcSUPPLYtemp + 2 && valvePAUSE == true && valveOPEN == false && millis() > ValveCLOSINGtime) {
    ValveERROR = SUPPLYtemp - (CalcSUPPLYtemp + 2);
#ifdef DEBUG
    Debug.print("ValveERROR : ");
    Debug.println(ValveERROR);
#endif
    if (ValveERROR > 2) {  // If the difference is big
      ValveCLOSINGtime = millis() + 3000 - 1000 + (ValveERROR * 500);
#ifdef DEBUG
      Debug.println("If Supply >= CalcSupply + 2 then CLOSE SMALL");
#endif
    } else {  // If the difference is small
      ValveCLOSINGtime = millis() + 3000;
#ifdef DEBUG
      Debug.println("If Supply >= CalcSupply + 2 then CLOSE BIG");
#endif
    }
    valveOPEN = false;
    valvePAUSE = false;
    valveCLOSE = true;
    CLOSE_VALVE();
  }
}

void OPEN_LSW_interrupt()  //ISR function excutes when LSW_OPENpin is HIGH
{
  // The valve has reached its maximum open position, it can only be closed or paused.
  valveOPEN = false;
  valvePAUSE = false;
  valveCLOSE = true;
  digitalWrite(LED_OPENpin, LOW);
  digitalWrite(LED_CLOSEpin, LOW);
  digitalWrite(LED_PAUSEpin, HIGH);
  digitalWrite(RelayCLOSEpin, LOW);
  digitalWrite(RelayOPENpin, LOW);
#ifdef DEBUG 	
  Debug.println("OPEN LSW interrupt");
#endif	
}


void CLOSE_LSW_interrupt()  //ISR function excutes when LSW_CLOSEpin is HIGH
{
  // The valve has reached its maximum close position, it can only be opened or paused.
  valveCLOSE = false;
  valvePAUSE = false;
  valveOPEN = true;
  digitalWrite(LED_OPENpin, LOW);
  digitalWrite(LED_CLOSEpin, LOW);
  digitalWrite(LED_PAUSEpin, HIGH);
  digitalWrite(RelayCLOSEpin, LOW);
  digitalWrite(RelayOPENpin, LOW);
#ifdef DEBUG 	
  Debug.println("CLOSE LSW interrupt");
#endif
}

// At reboot the system must to init with de VALVE CLOSED
void INITIAL_VALVE_CLOSING() {
  myNex.writeStr("Monitor.txt", "VALVE CONTROL MODE...\\r");
  myNex.writeStr("Monitor.txt+", "- First of all, the Valve must be in CLOSED mode.");
  myNex.writeStr("Monitor.txt+", "\\r- NOTE: This operation can take up to 4 minutes.");
  delay(500);
  // If isOpen && isClose are CLOSED: Valve is in intermediate position
  // If isOpen is CLOSED && isClose is OPEN: Valve is full CLOSED
  // Verify status of limit switches
  bool isOpen = digitalRead(LSW_OPENpin);    // Invert the state for active-low switches
  bool isClose = digitalRead(LSW_CLOSEpin);  // Invert the state for active-low switches

  unsigned long previousMillis = 0;    // Variable to store the last time the update was performed
  const unsigned long interval = 100;  // Interval to wait (in milliseconds) In de real world 1000
  if ((!isOpen && !isClose) || (isOpen && !isClose)) {  // If OPEN is FALSE or both OPEN and CLOSE are TRUE, perform actions
    digitalWrite(RelayOPENpin, HIGH);
    digitalWrite(RelayCLOSEpin, HIGH);
    myNex.writeStr("Monitor.txt+", "\\rCLOSING VALVE, please wait ");
#ifdef DEBUG
	Debug.println("CLOSING VALVE, please wait ");
#endif
    // At start Valve should be CLOSED
    //INITIAL_VALVE_CLOSING();
    //--
    while (!interruptClose) {
      unsigned long currentMillis = millis();  // Get the current time

      if (currentMillis - previousMillis >= interval) {
        previousMillis = currentMillis;  // Save the current time

        if (i < 32) {
          myNex.writeStr("Monitor.txt+", ".");
        } else if (i == 32) {
          myNex.writeStr("Monitor.txt+", "\\r.");
        } else if (i > 32 && i < 91) {
          myNex.writeStr("Monitor.txt+", ".");
        } else if (i == 91) {
          myNex.writeStr("Monitor.txt+", "\\r.");
        } else if (i > 91 && i <= 120) {
          myNex.writeStr("Monitor.txt+", ".");
        } else if (i == 121) {
          myNex.writeStr("Monitor.txt+", "\\rVALVE CLOSING FATAL ERROR !!!");
          myNex.writeStr("Monitor.txt+", "\\rTURN OFF THE CONTROLLER AND REFER TO THE MANUAL.");
          continueRunning = false;
          delay(3000);
        }
        i++;

        if (!continueRunning) {
          // If the flag is false, stop further execution
          while (1) {
            // This will create an infinite loop, stopping further execution
          }
        }
      }
    }  // end while

  } else {
    // Otherwise, perform alternative actions
  valvePAUSE = true;
  valveCLOSE = false;
  valveOPEN = false;
      // LEDs
  digitalWrite(LED_OPENpin, LOW);
  digitalWrite(LED_PAUSEpin, HIGH);
  digitalWrite(LED_CLOSEpin, LOW);
  // Relays
  digitalWrite(RelayOPENpin, LOW);
  digitalWrite(RelayCLOSEpin, LOW);
  }
#ifdef DEBUG   
  Debug.println("- CLOSED!!!");
#endif  
  myNex.writeStr("Monitor.txt+", "\\rVALVE IS CLOSED, GOING PAUSE!!!");
  valvePAUSE = true;
  valveCLOSE = false;
  valveOPEN = false;
      // LEDs
  digitalWrite(LED_OPENpin, LOW);
  digitalWrite(LED_PAUSEpin, HIGH);
  digitalWrite(LED_CLOSEpin, LOW);
  // Relays
  digitalWrite(RelayOPENpin, LOW);
  digitalWrite(RelayCLOSEpin, LOW);
  delay(3000);
}
