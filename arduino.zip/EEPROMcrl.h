// EEPROMctrl.h v.ALFA
// Created 22/09/2024

void SENDinit2NEX(void);

// EEPROM PUT FUNCTIONS
/*void EEPROM_put_INIT4() {
  EEPROM.put(eeADDRPIDctrl, PIDctrl0W);
  Delay();
}
*/
void EEPROM_put_INIT3() {
  EEPROM.put(eeADDRsettings2, Settings2W);
  Delay();
}
void EEPROM_put_INIT2() {
  EEPROM.put(eeADDRsettings1, Settings1W);
  Delay();
}
void EEPROM_put_INIT1() {
  EEPROM.put(eeADDRschedr, SchedrW);
  Delay();
}

// EEPROM GET FUNCTIONS
/*
void EEPROM_get_INIT4() {
  EEPROM.get(eeADDRPIDctrl, PIDctrl0R);
  Delay();
  if (SETUP) {  // We are in SETUP
    String KpString = String(PIDctrl0R.Kp);
    String KiString = String(PIDctrl0R.Ki);
    String KdString = String(PIDctrl0R.Kd);
	 myNex.writeStr("Monitor.txt", "PID control variables...\\r");
	 myNex.writeStr("Monitor.txt+", "- Kp  : ");
    myNex.writeStr("Monitor.txt+", KpString + "\\r");
	 myNex.writeStr("Monitor.txt+", "- Ki  : ");
    myNex.writeStr("Monitor.txt+", KiString + "\\r");
	 myNex.writeStr("Monitor.txt+", "- Kd  : ");
    myNex.writeStr("Monitor.txt+", KdString + "\\r");
	  
  }
}
*/
void EEPROM_get_INIT3() {
  EEPROM.get(eeADDRsettings2, Settings2R);
  Delay();
  if (SETUP) {  // We are in SETUP
    myNex.writeStr("Monitor.txt", "WiFi variables...\\r");
    myNex.writeStr("Monitor.txt+", "- Server 1 : ");
    myNex.writeStr("Monitor.txt+", String(Settings2R.SRVR1) + "\\r");
    myNex.writeStr("Monitor.txt+", "- Server 2 : ");
    myNex.writeStr("Monitor.txt+", String(Settings2R.SRVR2) + "\\r");
	 myNex.writeStr("Monitor.txt+", "- Server 3 : ");
    myNex.writeStr("Monitor.txt+", String(Settings2R.SRVR3) + "\\r");
    myNex.writeStr("Monitor.txt+", "- SSID     : ");
    myNex.writeStr("Monitor.txt+", String(Settings2R.SSID) + "\\r");
    myNex.writeStr("Monitor.txt+", "- Password : ");
    myNex.writeStr("Monitor.txt+", String(Settings2R.PSWD) + "\\r");
    myNex.writeStr("Monitor.txt+", "Valve time variables...\\r");
    String OPENINGtimeString = String(Settings2R.OPENINGtime);
    myNex.writeStr("Monitor.txt+", "- Opening  : ");
    myNex.writeStr("Monitor.txt+", OPENINGtimeString + " secs.\\r");
    String CLOSINGtimeString = String(Settings2R.CLOSINGtime);
    myNex.writeStr("Monitor.txt+", "- Closing  : ");
    myNex.writeStr("Monitor.txt+", CLOSINGtimeString + " secs.\\r");
    String PAUSINGtimeString = String(Settings2R.PAUSINGtime);
    myNex.writeStr("Monitor.txt+", "- Pausing  : ");
    myNex.writeStr("Monitor.txt+", PAUSINGtimeString + " secs.\\r");
  }
}
void EEPROM_get_INIT2() {
  EEPROM.get(eeADDRsettings1, Settings1R);
  Delay();
	if (SETUP) {  // We are in SETUP
		myNex.writeStr("Monitor.txt", "SYSTEM INITIALIZATION...\\r");
		delay(500);
		myNex.writeStr("Monitor.txt+", "- Boiler power     : ");
      myNex.writeStr("Monitor.txt+", String(Settings1R.BlrPWR) + " kCal/h\\r");
		myNex.writeStr("Monitor.txt+", "- MaxSupply temp.  : ");
      myNex.writeStr("Monitor.txt+", String(Settings1R.maxSuppTemp) + " ºC\\r");
		myNex.writeStr("Monitor.txt+", "- Min.Outdoor temp.: ");
      myNex.writeStr("Monitor.txt+", String(Settings1R.minOutdTemp) + " ºC\\r");
		myNex.writeStr("Monitor.txt+", "- SetPoint         : ");
      myNex.writeStr("Monitor.txt+", String(Settings1R.SetPoint) + " ºC\\r");
		myNex.writeStr("Monitor.txt+", "- SetBack          : ");
      myNex.writeStr("Monitor.txt+", String(Settings1R.SetBack) + " ºC\\r"); 
		myNex.writeStr("Monitor.txt+", "- Trip temp.       : ");
      myNex.writeStr("Monitor.txt+", String(Settings1R.Trip) + " ºC\\r"); 
		myNex.writeStr("Monitor.txt+", "END SYSTEM INITIALIZATION...\\r");
		delay(3000);
		myNex.writeStr("Monitor.txt", "START NTCs INITIALIZATION...\\r");
		delay(500);
		myNex.writeStr("Monitor.txt+", "- NTC0 (Outdoor): ");
		if (Settings1R.NTC0_Instl) {
			NTC0pin = 0;
			pinMode(NTC0pin, INPUT);
			myNex.writeStr("Monitor.txt+", "Installed");
		} else {
			myNex.writeStr("Monitor.txt+", "NOT installed");
		}
		myNex.writeStr("Monitor.txt+", "\\r");
		myNex.writeStr("Monitor.txt+", "- NTC1 (Supply) : ");
		if (Settings1R.NTC1_Instl) {
			NTC1pin = 1;
			pinMode(NTC1pin, INPUT);
			myNex.writeStr("Monitor.txt+", "Installed");
		} else {
			myNex.writeStr("Monitor.txt+", "NOT installed");
		}
		myNex.writeStr("Monitor.txt+", "\\r");
		myNex.writeStr("Monitor.txt+", "- NTC2 (Boiler) : ");
		if (Settings1R.NTC2_Instl) {
			NTC2pin = 2;
			pinMode(NTC2pin, INPUT);
			myNex.writeStr("Monitor.txt+", "Installed");
		} else {
			myNex.writeStr("Monitor.txt+", "NOT installed");
		}
		myNex.writeStr("Monitor.txt+", "\\r");
		myNex.writeStr("Monitor.txt+", "- NTC3 (Return) : ");
		if (Settings1R.NTC3_Instl) {
			NTC3pin = 3;
			pinMode(NTC3pin, INPUT);
			myNex.writeStr("Monitor.txt+", "Installed");
		} else {
			myNex.writeStr("Monitor.txt+", "NOT installed");
		}
		myNex.writeStr("Monitor.txt+", "\\rEND NTCs INITIALIZATION!!!");
		delay(3000);
	}
}

void EEPROM_get_INIT1() {
  EEPROM.get(eeADDRschedr, SchedrR);
  Delay();
}

void VERIFY_EEPROM_INIT() {
  myNex.writeStr("Monitor.txt", "EEPROM VERIFICATION...\\r");
  myNex.writeStr("Monitor.txt+", "- Normal Reboot: EEPROM reading and sending it to\\r");
  myNex.writeStr("Monitor.txt+", "  the display.\\r");
  myNex.writeStr("Monitor.txt+", "- New Firmware Reboot: EEPROM recording followed\\r");
  myNex.writeStr("Monitor.txt+", "  by a Normal Reboot.\\r");
  Delay();
  char readData[5];
  for (eeADDRversion = 0; eeADDRversion < 5; eeADDRversion++) {
    readData[eeADDRversion] = EEPROM.read(eeADDRversion);
  }
  // Compare the read data with VERSION
  if (memcmp(readData, VERSION, 5) == 0) {  // Versions MATCH !!!
    myNex.writeStr("Monitor.txt+", "VERSION MATCH!!!\\r");
	 #ifdef DEBUG
    Debug.println("Versions match!");
	 #endif
    Delay();
  } else {  // Versions DON'T MATCH !!!
    myNex.writeStr("Monitor.txt+", "VERSION DON'T MATCH!!!\\r");
	 #ifdef DEBUG
    Debug.println("Versions do not match!");
	 #endif
    Delay();
    // 1st write VERSION to EEPROM
    myNex.writeStr("Monitor.txt+", "- Putting new version.\\r");
    for (eeADDRversion = 0; eeADDRversion < 5; eeADDRversion++) {
      EEPROM.write(eeADDRversion, VERSION[eeADDRversion]);
    }
    Delay();
    // 2nd put initial Settings vars
    myNex.writeStr("Monitor.txt+", "- Putting new data.\\r");
    //EEPROM_put_INIT4();
    //Delay();
    EEPROM_put_INIT3();
    Delay();
    EEPROM_put_INIT2();
    Delay();
    EEPROM_put_INIT1();
    Delay();
  }  // END else
  myNex.writeStr("Monitor.txt+", "- Getting data.\\r");
  //EEPROM_get_INIT4();
  //Delay();
  EEPROM_get_INIT3();
  Delay();
  EEPROM_get_INIT2();
  Delay();
  EEPROM_get_INIT1();
  Delay();
  myNex.writeStr("Monitor.txt+", "\\r");
  myNex.writeStr("Monitor.txt+", "\\rEND EEPROM VERIFICATION!!!");
  delay(3000);
}
